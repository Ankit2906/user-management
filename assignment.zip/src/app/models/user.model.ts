export class User {
  accountId: string;
  age: number;
  firstName: string;
  lastName: string;
}
